package com.company;

public class Main {

    public static void main(String[] args) {
        creatObject("Лягушка");
        creatObject("Головастик");
        creatObject("Икра");


    }

    public static void creatObject(String className) {
        String name = className;
        switch (className) {
            case "Лягушка":
                Frog frog = new Frog("Скольская", "Красные", "4", "1", "Лягушка");
                frog.print();
                System.out.println("------------------------");
                break;
            case "Головастик":
                Tadpole tadpole = new Tadpole("Черный", "Дышать", "Голавастик");
                tadpole.print();
                System.out.println("------------------------");
                break;
            case "Икра":
                Caviar caviar = new Caviar("Склиская", "Черная", "Икра");
                caviar.print();
                System.out.println("-------------------------");
                break;
        }


    }
}
